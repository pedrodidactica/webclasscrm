<?php
/*********************************************************************************
 * The content of this file is subject to the EMAIL Maker license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/
 
if (file_exists('vtwsclib/Vtiger/WSClient.php'))
{
    include_once('vtwsclib/Vtiger/WSClient.php');
    
    $server_path = '';
    $user_name = '';
    $user_access_key = '';
    
    $update = false;
        
    if ($server_path != "" && $user_name != "" && $user_access_key != "")
    {
        
        $client = new Vtiger_WSClient($server_path);
        $login = $client->doLogin($user_name,$user_access_key);
        
        
        if(!$login)
        {
            echo "Login failed";
        } 
        else 
        {
            //echo "Login OK";
            
            $c_module = $client->doDescribe("Contacts");
            $cid = $c_module["idPrefix"];
        
            $a_module = $client->doDescribe("Accounts");
            $aid = $a_module["idPrefix"];
        
            $crmid = $_REQUEST["u"];
            $small_code = $_REQUEST["c"];
            
            $code = md5($crmid.$server_path);
            $small_code = substr($code, 5, 6);
            
            if ($small_code == $small_code)
            { 
                $contact = $client->doRetrieve($cid."x".$crmid);
            
                if ($contact)
                {
                    $contact["emailoptout"] = "1";
                    $update = $client->doUpdate($contact);
                }
                
                $account = $client->doRetrieve($aid."x".$crmid);
            
                if ($account)
                {
                    $account["emailoptout"] = "1";
                    $update = $client->doUpdate($account);
                }
                
                
            }
            else
            {
                
            }
        }
    }
    
    echo "<br /><br /><br /><center><b>";
    
    if ($update) 
        echo "Your email address has been unsubscribed.</b></center>";
    else 
        echo "Your email address has not been unsubscribed. Set parrameters are wrong.";
        
    echo "</b></center>";    
}
else
{
    echo "file &quot;vtwsclib/Vtiger/WSClient.php&quot; not exist";
}
?>
